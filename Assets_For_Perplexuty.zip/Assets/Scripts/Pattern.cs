public class Pattern 
{
   public string patternString;
}